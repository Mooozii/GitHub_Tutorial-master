## git 命令

### 基本的 git 命令

* git init：初始化操作
* git add：
* git commit -m "注释"：

