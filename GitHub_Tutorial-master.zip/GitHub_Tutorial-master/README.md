# GitHub Tutorial
> **公众号：老沈靠谱**

## 目录

- [mac os 命令](chapter1.md)
- [git 命令](chapter2.md)
- [github 命令](chapter3.md)
- [github 概念](chapter4.md)
- [常见问题及解决方案](chapter5.md)

## 学习资源

- [GitHub 官方学习资源](https://opensource.guide/starting-a-project/)
